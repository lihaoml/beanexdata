#include <iostream>
#include <functional>
#include <fstream>
#include "BSAnalytics.h"

#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/io.hpp>
#include <boost/numeric/ublas/lu.hpp>

using namespace boost::numeric::ublas;

template<class T>
bool InvertMatrix(const matrix<T>& input, matrix<T>& inverse);

enum BoundaryType { Dirichlet, Neumann, Linear };

double pdeExplicit( std::function<double(double)> payoff, int NS, int NT, BoundaryType bTy
	  , double S, double T, double r, double q, double sigma)
{
  // set up parameters
  double mu = r - q;
  double range = 5 * sigma * std::sqrt(T); // we define the range to be +- 5 stdev
  double maxS = S * std::exp((mu - sigma * sigma * 0.5)*T + range);
  double minS = S * std::exp((mu - sigma * sigma * 0.5)*T - range);
  double dt = T / (NT-1);
  double ds = (maxS - minS) / (NS-1);

  std::cout << "maxS = " << maxS << std::endl;
  std::cout << "minS = " << minS << std::endl;
  std::cout << "dt = " << dt << std::endl;
  std::cout << "ds = " << ds << std::endl;
  std::cout << "cond1 = " << dt / ds / ds * sigma * sigma * maxS * maxS << std::endl;
  std::cout << "cond2 = " << ds / sigma / sigma / minS * (r-q) << std::endl;
    
  // the spot grid
  vector<double> sGrid(NS);
  
  // initialize the payoff
  vector<double> ps(NS);
  for (int i=0; i < NS; i++) {
    sGrid(i) = minS + i*ds;
    ps(i) = payoff(sGrid(i));
  }

  // set up the matrix, for BS the matrix does not change,
  // for LV we need to update it for each iteration
  double a = mu / 2.0 / ds;  // repeatly used quantities
  double b = sigma * sigma / ds / ds;
  matrix<double> M(NS, NS, 0.0);
  matrix<double> D(NS, NS, 0.0);
  for (int i=1; i<NS-1; i++) {
    M(i, i-1) = a*sGrid(i) - b*sGrid(i)*sGrid(i)/2.0;
    M(i, i) = r + b*sGrid(i)*sGrid(i);
    M(i, i+1) = -a*sGrid(i) - b*sGrid(i)*sGrid(i)/2.0;
    D(i, i) = 1.0;
  }
  // the first row and last row depends on the boundary condition
  switch(bTy) {
  case Dirichlet:
    M(0, 0) = 1.0; M(NS-1, NS-1) = 1.0; break;
  case Neumann:
    M(0, 0) = -1; M(0, 1) = 1;
    M(NS-1, NS-2) = -1; M(NS-1, NS-1) = 1;
    break;
  case Linear:
    M(0, 0) = 1; M(0, 1) = -2; M(0, 2) = 1;
    M(NS-1, NS-3) = 1; M(NS-1, NS-2) = -2; M(NS-1, NS-1) = 1; break;
  default:
    throw "unrecognized boundary condition type";
  };

  std::ofstream fout("eulerExplicitEvolution.txt");
  for(int i = 0; i < NS; i++) {
    fout << T << "\t" << sGrid(i) << "\t" << ps(i) << std::endl;
  }
  
  M = D - dt * M; 
  // backward induction
  for (int j = 1; j < NT; j++) {
    ps = prod(M, ps); // Euler explicit
    // force the boundary points
    switch(bTy) {
    case Dirichlet:
      ps(0) = std::exp(-r*(j*dt)) * payoff(sGrid(0)); // discounted payoff
      ps(NS-1) = std::exp(-r*(j*dt)) * payoff(sGrid(NS-1));
      break;
    default:
      throw "unrecognized boundary condition type";
    };

    for(int i = 0; i < NS; i++) {
      fout << (T-j*dt) << "\t" << sGrid(i) << "\t" << ps(i) << std::endl;
    }
  }

  // return result for S
  std::cout << ps << std::endl;

  // linear interpolate
  int idx = std::floor((S-minS)/ds);
  double w = (S-sGrid(idx)) / (sGrid(idx+1) - sGrid(idx));
  std::cout << sGrid(idx) << std::endl;
  std::cout << sGrid(idx+1) << std::endl;

  std::ofstream fout2("eulerExplicitBlowUp2.txt");
  for(int i = 0; i < NS; i++) {
    fout2 << sGrid(i) << "\t" << ps(i) << std::endl;
  }

  return ps(idx) * (1-w) + w * ps(idx+1);
}

int main()
{
  //  auto call = [](double S){return std::max(S-90, 0);};
  double K = 100;
  auto call = [K](double S){return S>K?S-K:0;};

  double pdePrice = pdeExplicit(call, 50, 60, Dirichlet, 100, 1, 0.05, 0.02, 0.15);
  double bsPrice = bsPricer(Call, K, 1, 100, 0.15, 0.05, 0.02);
  std::cout << "pde price: \t" << pdePrice << std::endl;
  std::cout << "bs price: \t" << bsPrice << std::endl;

  //  return 0; 
  std::ofstream fout("explicitEurlerError.txt");
  double nt = 5;
  double ns = 5;
  for (int i = 0; i < 100; i++) {
    pdePrice = pdeExplicit(call, ns, nt, 
		   Dirichlet, 100, 1, 0.05, 0.02, 0.15);
    fout << (int)nt << "\t" << std::abs(pdePrice - bsPrice) << std::endl;
    ns *= 1.1;
    nt *= 1.21;
  }
  return 0;
}


// Matrix inversion routine.
// Uses lu_factorize and lu_substitute in uBLAS to invert a matrix
template<class T>
bool InvertMatrix(const matrix<T>& input, matrix<T>& inverse)
{
  typedef permutation_matrix<std::size_t> pmatrix;
  // create a working copy of the input
  matrix<T> A(input);
  // create a permutation matrix for the LU-factorization
  pmatrix pm(A.size1());
  // perform LU-factorization
  int res = lu_factorize(A, pm);
  if (res != 0)
    return false;
  // create identity matrix of "inverse"
  inverse.assign(identity_matrix<T> (A.size1()));
  // backsubstitute to get the inverse
  lu_substitute(A, pm, inverse);
  return true;
}
