#include <iostream>
#include <functional>
#include <fstream>
#include "BSAnalytics.h"

#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/io.hpp>
#include <boost/numeric/ublas/lu.hpp>

using namespace boost::numeric::ublas;

template<class T>
bool InvertMatrix(const matrix<T>& input, matrix<T>& inverse);

enum BoundaryType { Dirichlet, Neumann, Linear };

typedef permutation_matrix<std::size_t> pmatrix;

double pdeImplicit( std::function<double(double)> payoff, int NS, int NT, BoundaryType bTy
	  , double S, double T, double r, double q, double sigma)
{
  // set up parameters
  double mu = r - q;
  double range = 5 * sigma * std::sqrt(T); // we define the range to be +- 5 stdev
  double maxS = S * std::exp((mu - sigma * sigma * 0.5)*T + range);
  double minS = S * std::exp((mu - sigma * sigma * 0.5)*T - range);
  double dt = T / (NT-1);
  double ds = (maxS - minS) / (NS-1);

  // the spot grid
  vector<double> sGrid(NS);
  
  // initialize the payoff
  vector<double> ps(NS);
  for (int i=0; i < NS; i++) {
    sGrid(i) = minS + i*ds;
    ps(i) = payoff(sGrid(i));
  }

  // set up the matrix, for BS the matrix does not change,
  // for LV we need to update it for each iteration
  double a = mu / 2.0 / ds;  // repeatly used quantities
  double b = sigma * sigma / ds / ds;
  matrix<double> M(NS, NS, 0.0);
  matrix<double> D(NS, NS, 0.0);
  for (int i=1; i<NS-1; i++) {
    M(i, i-1) = a*sGrid(i) - b*sGrid(i)*sGrid(i)/2.0;
    M(i, i) = r + b*sGrid(i)*sGrid(i);
    M(i, i+1) = -a*sGrid(i) - b*sGrid(i)*sGrid(i)/2.0;
    D(i, i) = 1.0;
  }
  // the first row and last row depends on the boundary condition
  switch(bTy) {
  case Dirichlet:
    M(0, 0) = 1.0; M(NS-1, NS-1) = 1.0; break;
  case Neumann:
    M(0, 0) = -1; M(0, 1) = 1;
    M(NS-1, NS-2) = -1; M(NS-1, NS-1) = 1;
    break;
  case Linear:
    M(0, 0) = 1; M(0, 1) = -2; M(0, 2) = 1;
    M(NS-1, NS-3) = 1; M(NS-1, NS-2) = -2; M(NS-1, NS-1) = 1; break;
  default:
    throw "unrecognized boundary condition type";
  };
  
  M = D + dt * M;
  // perform LU-factorization --- do it only once since M doesn't change for BS
  pmatrix pm(M.size1());
  lu_factorize(M, pm);

  // backward induction
  for (int j = 1; j < NT; j++) {
    // force the boundary points
    switch(bTy) {
    case Dirichlet:
      ps(0) = dt*std::exp(-r*(j*dt)) * payoff(sGrid(0)); // discounted payoff
      ps(NS-1) = dt*std::exp(-r*(j*dt)) * payoff(sGrid(NS-1));
      break;
    default:
      throw "unrecognized boundary condition type";
    };
    lu_substitute(M, pm, ps);
  }

  // return result for S
  std::cout << ps << std::endl;

  // linear interpolate
  int idx = std::floor((S-minS)/ds);
  double w = (S-sGrid(idx)) / (sGrid(idx+1) - sGrid(idx));
  std::cout << sGrid(idx) << std::endl;
  std::cout << sGrid(idx+1) << std::endl;

  return ps(idx) * (1-w) + w * ps(idx+1);
}

int main()
{
  //  auto call = [](double S){return std::max(S-90, 0);};
  double K = 100;
  auto call = [K](double S){return S>K?S-K:0;};

  double pdePrice = pdeImplicit(call, 50, 100, Dirichlet, 100, 1, 0.05, 0.02, 0.15);
  double bsPrice = bsPricer(Call, K, 1, 100, 0.15, 0.05, 0.02);
  std::cout << "pde price: \t" << pdePrice << std::endl;
  std::cout << "bs price: \t" << bsPrice << std::endl;

  //  return 0; 
  std::ofstream fout("implicitEurlerError.txt");
  double nt = 5;
  double ns = 5;
  for (int i = 0; i < 100; i++) {
    pdePrice = pdeImplicit(call, ns, nt, 
		   Dirichlet, 100, 1, 0.05, 0.02, 0.15);
    fout << (int)nt << "\t" << std::abs(pdePrice - bsPrice) << std::endl;
    ns *= 1.21;
    nt *= 1.21;
  }
  return 0;
}
