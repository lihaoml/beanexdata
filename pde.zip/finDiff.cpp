#include <iostream>
#include <iomanip>
#include <cmath>

int main()
{
  // first derivative of e^x at x = 1
  double x0 = 1;
  double deriv = std::exp(x0);
  double h = 1;
  for (int i = 0; i<60; i++) {
    h = h / 2;
    // one sided difference
    double findiff = (std::exp(x0+h) - std::exp(x0)) / h;
    // central difference
    // double findiff = (std::exp(x0+h) - std::exp(x0-h)) / h / 2;
    // Richardson extrapolation
    double step_h = (std::exp(x0+h) - std::exp(x0-h)) / h / 2;
    double step_2h = (std::exp(x0+2*h) - std::exp(x0-2*h)) / h / 4;    
    //    double findiff = (4*step_h - step_2h) / 3;
    std::cout << std::setprecision(15) << h << "\t" << std::abs(findiff - deriv) << std::endl;
  }
      
  return 0;
}
