import math
import numpy as np
import matplotlib.pyplot as plt
from binomial import EuropeanOption, PayoffType, bsPrice, binomialPricer, crrCalib, simpleCRR
from impliedvol import LocalVol, ImpliedVol, Smile, smileFromMarks, strikeFromDelta, testFlatImpliedVol


def createTestImpliedVol(S, r, q):
    pillars = [0.02, 0.04, 0.06, 0.08, 0.16, 0.25, 0.75, 1.0, 1.5, 2, 3, 5]
    atmvols = [0.155, 0.1395, 0.1304, 0.1280, 0.1230, 0.1230, 0.1265, 0.1290, 0.1313, 0.1318, 0.1313, 0.1305, 0.1295]
    bf25s = [0.0016, 0.0016, 0.0021, 0.0028, 0.0034, 0.0043, 0.0055, 0.0058, 0.0060, 0.0055, 0.0054, 0.0050, 0.0045, 0.0043]
    rr25s = [-0.0065, -0.0110, -0.0143, -0.0180, -0.0238, -0.0288, -0.0331, -0.0344, -0.0349, -0.0340, -0.0335, -0.0330, -0.0330]
    bf10s = [0.0050, 0.0050, 0.0067, 0.0088, 0.0111, 0.0144, 0.0190, 0.0201, 0.0204, 0.0190, 0.0186, 0.0172, 0.0155, 0.0148]
    rr10s = [-0.0111, -0.0187, -0.0248, -0.0315, -0.0439, -0.0518, -0.0627, -0.0652, -0.0662, -0.0646, -0.0636, -0.0627, -0.0627]
    smiles = [smileFromMarks(pillars[i], S, r, q, atmvols[i], bf25s[i], rr25s[i], bf10s[i], rr10s[i]) for i in range(len(pillars))]
    return ImpliedVol(pillars, smiles)

def createTestImpliedVol2(S, r, q, c):
    pillars = [0.02, 0.04, 0.06, 0.08, 0.16, 0.25, 0.75, 1.0, 1.5, 2, 3, 5]
    # atmvols = [0.155, 0.1395, 0.1304, 0.1280, 0.1230, 0.1230, 0.1265, 0.1290, 0.1313, 0.1318, 0.1313, 0.1305, 0.1295]
    atmvols = [0.155, 0.153, 0.15, 0.148, 0.146, 0.14, 0.13, 0.1290, 0.1313, 0.1318, 0.1313, 0.1305, 0.1295]
    bf25s = [0.0016, 0.0016, 0.0021, 0.0028, 0.0034, 0.0043, 0.0055, 0.0058, 0.0060, 0.0055, 0.0054, 0.0050, 0.0045, 0.0043]
    rr25s = [-0.0065, -0.0110, -0.0143, -0.0180, -0.0238, -0.0288, -0.0331, -0.0344, -0.0349, -0.0340, -0.0335, -0.0330, -0.0330]
    bf10s = [0.0050, 0.0050, 0.0067, 0.0088, 0.0111, 0.0144, 0.0190, 0.0201, 0.0204, 0.0190, 0.0186, 0.0172, 0.0155, 0.0148]
    rr10s = [-0.0111, -0.0187, -0.0248, -0.0315, -0.0439, -0.0518, -0.0627, -0.0652, -0.0662, -0.0646, -0.0636, -0.0627, -0.0627]
    smiles = [smileFromMarks(pillars[i], S, r, q, atmvols[i], bf25s[i]*c, rr25s[i]*c, bf10s[i]*c, rr10s[i]*c) for i in range(len(pillars))]
    return ImpliedVol(pillars, smiles)


def calibImpliedTree(S, r, q, iv, T, n):
    # vol = iv.Vol(0, S)
    t = T / n
    treeNodes = [[S]] # at t = 0, only one node,
    probs = [[]]
    adprice = [[1.0]]
    df = math.exp(-r*t)
    dfq = math.exp(-q*t)

    for k in range(1, n+1):
        # calculate the value of each node at time slide i, there are i+1 nodes
        slice = [0] * (k+1)
        upStartIdx, downStartIdx = 0, 0
        kt = k * t
        if k % 2 == 0:
            upStartIdx = downStartIdx = round(k/2)
            slice[upStartIdx] = S
        else:
            upStartIdx, downStartIdx = math.floor(k/2), math.ceil(k/2)
            vol = iv.Vol(S, kt)
            b = bsPrice(S, r, vol, kt, S, PayoffType.Call) / df
            # b = binomialPricer(S, r, vol, EuropeanOption(kt, S, PayoffType.Call), k, simpleCRR) / df

            for j in range(upStartIdx):
                fwd = treeNodes[k - 1][j] * dfq / df
                b = b - adprice[k - 1][j] * (fwd - S)
            slice[upStartIdx] = S*(b + adprice[k-1][upStartIdx]*S) / (adprice[k-1][upStartIdx]*S*dfq/df-b)
            slice[downStartIdx] = S*S / slice[upStartIdx]
            print(S, k, vol, upStartIdx, downStartIdx, slice[upStartIdx], slice[downStartIdx])

            # arbitrage handling
            if (slice[downStartIdx] >= S * dfq / df) or (downStartIdx < k and slice[downStartIdx] <= treeNodes[k - 1][downStartIdx] * dfq / df):
                if i < k:
                    slice[downStartIdx] = (S + treeNodes[k - 1][downStartIdx]) / 2 * dfq / df
            if (slice[upStartIdx] <= S * dfq / df) or (upStartIdx > 0 and slice[upStartIdx] >= treeNodes[k-1][upStartIdx-1] * dfq / df):
                if i > 0:
                    slice[upStartIdx] = (S + treeNodes[k - 1][upStartIdx-1]) / 2 * dfq / df

        # constructing nodes above
        for i in range(upStartIdx-1, -1, -1):
            s0 = treeNodes[k-1][i]
            vol = iv.Vol(s0, kt)
            b = bsPrice(S, r, vol, kt, s0, PayoffType.Call) / df
            # b = binomialPricer(S, r, vol, EuropeanOption(kt, s0, PayoffType.Call), k, simpleCRR) / df
            for j in range(i):
                fwd = treeNodes[k-1][j]*dfq/df
                b = b - adprice[k-1][j]*(fwd-s0)
            sd = slice[i+1]
            su = (sd * b - adprice[k-1][i]*s0*(s0*dfq/df-sd)) / (b - adprice[k-1][i] * (s0*dfq/df-sd))

            # arbitrage handling
            if (su <= s0*dfq/df) or (i > 0 and su >= treeNodes[k-1][i-1]*dfq/df) or (i == 0 and su >= s0 * s0 / treeNodes[k-1][i+1] * dfq/df):
                su = s0 * sd / treeNodes[k-1][i+1]
#                print(k, i, s0, treeNodes[k - 1][i + 1], sd, su)
                if (su <= s0 * dfq / df) or (i > 0 and su >= treeNodes[k - 1][i - 1]):
                    if i > 0:
                        su = (s0 + treeNodes[k-1][i-1]) / 2 *dfq/df
            slice[i] = su

        # constructing nodes below
        for i in range(downStartIdx+1, k+1):
            s0 = treeNodes[k-1][i-1]
            vol = iv.Vol(s0, kt)
            # print(vol, kt, s0)
            # b = bsPrice(S, r, vol, kt, s0, PayoffType.Put) / df
            # b = binomialPricer(S, r, vol, EuropeanOption(kt, s0, PayoffType.Put), k, simpleCRR) / df
            for j in range(i, k):
                fwd = treeNodes[k-1][j]*dfq/df
                b = b - adprice[k-1][j]*(s0-fwd)
            su = slice[i-1]
            sd = (su * b + adprice[k-1][i-1]*s0*(s0*dfq/df-su)) / (b+adprice[k-1][i-1] * (s0*dfq/df - su))
            # arbitrage handling
            if (sd >= s0*dfq/df) or (i < k and sd <= treeNodes[k-1][i] *dfq/df) or (i == k and sd <= s0 * s0 / treeNodes[k-1][i-2] * dfq/df):
                sd = s0 * su / treeNodes[k - 1][i - 2]
                if (sd >= s0 * dfq / df) or (i < k and sd <= treeNodes[k - 1][i] * dfq / df):
                    if i < k:
                        sd = (s0 + treeNodes[k-1][i]) / 2 * dfq / df
            slice[i] = sd

        if False:
            vol = iv.Vol(0, S)
            for i in range(k):
                slice[i] = treeNodes[k-1][i] * math.exp(vol * math.sqrt(t))
            slice[k] = treeNodes[k-1][k-1] * math.exp(-vol * math.sqrt(t))

        treeNodes.append(slice)

        prob = [0] * (k)
        for i in range(k):
            # print(k, treeNodes[k][i], treeNodes[k][i + 1])
            if (treeNodes[k][i] - treeNodes[k][i+1]) < 1e-8:
                print(T, k, i, treeNodes[k][i], treeNodes[k][i+1])
            prob[i] = (treeNodes[k-1][i] * dfq / df - treeNodes[k][i+1]) / (treeNodes[k][i] - treeNodes[k][i+1])
        probs.append(prob)

        ad = [0] * (k+1)
        ad[0] = adprice[k-1][0] * probs[k][0] * df
        for i in range(1, k):
            ad[i] = ((1-probs[k][i-1]) * adprice[k-1][i-1] + probs[k][i]*adprice[k-1][i]) * df
        ad[k] = adprice[k-1][k-1] * (1-probs[k][k-1]) * df
        adprice.append(ad)

    return treeNodes, probs, adprice

def impliedTreePricer(S, r, q, iv, NT, trade):
    t = trade.expiry / NT
    treeNodes, probs, adprice = calibImpliedTree(S, r, q, iv, trade.expiry, NT)
    # set up the last time slice, there are n+1 nodes at the last time slice
    vs = [trade.payoff(treeNodes[NT][i]) for i in range(NT + 1)]
    # vs = [trade.payoff(treeNodes[NT][i]) * adprice[NT][i] for i in range(NT + 1)]
    # return sum(vs)
    # iterate backward
    for i in range(NT - 1, -1, -1):
        # calculate the value of each node at time slide i, there are i nodes
        for j in range(i + 1):
            nodeS = S * treeNodes[i][j]
            p = probs[i+1][j]
            continuation = math.exp(-r * t) * (vs[j] * p + vs[j + 1] * (1 - p))
            vs[j] = trade.valueAtNode(t * i, nodeS, continuation)
    return vs[0]

# the PDE calibration error report takes a implied volatility surface,
# verifies the pricing error of the pde pricer with local volatility surface
def treeCalibReport(S0, r, impliedVol):
    ts = [0.02, 0.04, 0.06, 1/12.0, 1/6.0, 1/4.0, 1/2.0, 1, 2, 5]
    ds = np.arange(0.9, 0., -0.1)
    # ds = np.arange(0.5, 1.7, 0.1)
    err = np.zeros((len(ds), len(ts)))
    fig, ax = plt.subplots()

    ax.set_xticks(np.arange(len(ts)))
    ax.set_yticks(np.arange(len(ds)))
    ax.set_xticklabels(map(lambda t : round(t, 2), ts))
    ax.set_yticklabels(map(lambda d : round(d, 1), ds))

    # Loop over data dimensions and create text annotations.
    for i in range(len(ds)):
        for j in range(len(ts)):
            T = ts[j]
            payoff = PayoffType.Put
            K = strikeFromDelta(S0, r, 0, T, iv.Vol(T, S0*math.exp(r*T)), ds[i], payoff) # ds[i]
            trade = EuropeanOption(T, K, payoff)
            vol = impliedVol.Vol(ts[j], K)
            bs = bsPrice(S0, r, vol, T, K, payoff)
            # treePrc = impliedTreePricer(S0, r, 0.0, impliedVol, max(50, int(30 * T)), trade)
            treePrc = impliedTreePricer(S0, r, 0.0, impliedVol, 200, trade)
            # print(T, K, bs, treePrc)
            # normalize error in 1 basis point per 1 unit of stock
            err[i, j] = math.fabs(bs - treePrc)/S0 * 10000
            ax.text(j, i, round(err[i, j], 1), ha="center", va="center", color="w")
    im = ax.imshow(err)
    ax.set_title("Dupire Calibration PV Error Matrix")
    fig.tight_layout()
    plt.show()

def showTree(S0, r, q, iv):
    T, nT = 2, 30
    dt = T / nT
    treeNodes, probs, adprice = calibImpliedTree(S0, r, q, iv, T, nT)
    fig = plt.figure()
    for i in range(len(treeNodes)-1):
        x = [dt, 0, dt]
        for j in range(i):
            x += [0, dt]
        x = np.array(x) + i*dt
        y = treeNodes[i] + treeNodes[i+1]
        y.sort()
        y = [S0 * math.exp(k) for k in y]
        plt.yscale('log')
        plt.plot(x, y, '-')
    plt.show()


if __name__ == "__main__":
    S, r, q = 1.25805, 0.0, 0.0
    # iv = createTestImpliedVol(S, r, q)
    iv = createTestImpliedVol2(S, r, q, 1.0)
    # iv = testFlatImpliedVol(S, r, q)
    showTree(S, r, q, iv)
    treeCalibReport(S, r, iv)

