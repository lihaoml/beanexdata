import pandas as pd
import numpy as np
import iso8601
import matplotlib.pyplot as plt
from dateutil.parser import parse


path = "~/.beanex/data/"

def loadRawData():
    z19_bmx = pd.read_csv(path+"/XBTZ19_201910_vwap.csv")
    h20_bmx = pd.read_csv(path+"/XBTH20_201910_vwap.csv")
    z19_drb = pd.read_csv(path+"/DeribitZ19_201910_txn.csv")
    h20_drb = pd.read_csv(path +"/DeribitH20_201910_txn.csv")
    bidx = pd.read_csv(path + "/bindex_201910.csv")
    didx = pd.read_csv(path + "/dindex_201910.csv")

    z19_bmx['Time'] = z19_bmx['Time'].apply(iso8601.parse_date)
    h20_bmx['Time'] = h20_bmx['Time'].apply(iso8601.parse_date)

    z19_b = z19_bmx.set_index('Time').Value.rename('Z19_B')
    h20_b = h20_bmx.set_index('Time').Value.rename('H20_B')

    bidx['Time'] = bidx['Time'].apply(parse)
    bidx = bidx.set_index('Time').Value.rename("B")

    freq = '60s'
    z19_drb['Time'] = z19_drb['Time'].apply(iso8601.parse_date)
    z19_drb = z19_drb.set_index('Time')

    h20_drb['Time'] = h20_drb['Time'].apply(iso8601.parse_date)
    h20_drb = h20_drb.set_index('Time')
    didx['Time'] = didx['Time'].apply(iso8601.parse_date)

    didx = didx.set_index('Time').resample(freq).mean().Price.rename("D") # .rename("D").resample(freq).avg() #.Price.resample(freq.avg())

    # z19 deribit 1m vwap
    z19_d = (((z19_drb.Price * z19_drb.Quantity).resample(freq).sum()) / z19_drb.Quantity.resample(freq).sum()).rename('Z19_D')
    h20_d = (((h20_drb.Price * h20_drb.Quantity).resample(freq).sum()) / h20_drb.Quantity.resample(freq).sum()).rename('H20_D')
    bbb = pd.concat([z19_b, z19_d, h20_b, h20_d, bidx, didx], axis=1)

    # drop rows with empty data
    bbb.dropna(axis=0, how='any', thresh=None, subset=None, inplace=True)
    # some B contract values are 0
    bbb = bbb[bbb.Z19_B > 1]
    bbb = bbb[bbb.H20_B > 1]
    bbb.to_csv(path + "bbb.csv")
    print(bbb.head())
    return bbb

def loadData():
    return pd.read_csv(path+ "bbb.csv")


bbb = loadData()

idxDiff = bbb.B - bbb.D
z19Diff = bbb.Z19_B - bbb.Z19_D
h20Diff = bbb.H20_B - bbb.H20_D
print(idxDiff)

plt.hist(idxDiff, alpha=0.5, bins=50, log=True, color='g', label='bidx')
plt.hist(z19Diff, alpha=0.5, bins=50, log=True, color='b', label='z19')
plt.hist(h20Diff, alpha=0.5, bins=50, log=True, color='r', label='h20')

# plt.xlim(50,75)
plt.show()
print(pd.concat([idxDiff.describe(), z19Diff.describe(), h20Diff.describe()], axis=1))

c1pos = 0  # c1 position at B, c1 position at D is -c1pos ideally
c2pos = 0  # c2 position at D, c2 position at D is -c2pos ideally
# delta_b, delta_d
# in the ideal world, delta c1 and c2 are 0, c1posAtD = -c1posAtB
# leave that to execution, maximum delta on c1 and c2 is the step size
# risk we need to manage is sum(c1pos) and sumabs(c1pos)
maxD = 1
p = 0.1 * maxD
NN = 10
mtm = 0
mean1 = z19Diff.mean()
tau1 = z19Diff.std()
mean2 = h20Diff.mean()
tau2 = h20Diff.std()
prevS1 = 0
txnCost = 0.001

# test algo
for i in range (0, len(bbb)):

    state = bbb.loc[i]
    s1 = state.Z19_B - state.Z19_D - mean1
    mtm += c1pos * (state.Z19_B - state.Z19_D - prevS1)
    prevS1 = state.Z19_B - state.Z19_D
    if s1 > mean1 + tau1:
        cond1 = abs(c1pos - p + c2pos) < maxD
        cond2 = abs(c1pos - p) + abs(c2pos) < maxD * NN
        if cond1 and cond2:  # we can short Z19_B, long Z19_D
            c1pos = c1pos - p
            mtm -= p * state.B * txnCost

    elif s1 > mean1:
        netexpReduced = abs(c1pos - p + c2pos) <= abs(c1pos + c2pos) # if enter the position helps reduce net exposure
        absexpReduced = abs(c1pos - p) + abs(c2pos) <= abs(c1pos) + abs(c2pos)
        netUsage = abs(c1pos + c2pos) / maxD
        absUsage = (abs(c1pos) + abs(c2pos)) / (maxD * NN)

        if  (netexpReduced and absexpReduced) or \
            (netexpReduced and not absexpReduced and netUsage > absUsage) or \
            (not netexpReduced and absexpReduced and absUsage > netUsage):
            c1pos = c1pos - p
            mtm -= p * state.B * txnCost

    elif s1 < mean1:
        netexpReduced = abs(c1pos + p + c2pos) <= abs(c1pos + c2pos)  # if enter the position helps reduce net exposure
        absexpReduced = abs(c1pos + p) + abs(c2pos) <= abs(c1pos) + abs(c2pos)
        netUsage = abs(c1pos + c2pos) / maxD
        absUsage = (abs(c1pos) + abs(c2pos)) / (maxD * NN)

        if (netexpReduced and absexpReduced) or \
                (netexpReduced and not absexpReduced and netUsage > absUsage) or \
                (not netexpReduced and absexpReduced and absUsage > netUsage):
            c1pos = c1pos + p
            mtm -= p * state.B * txnCost

    elif s1 < mean1 - tau1:
        cond1 = abs(c1pos + p + c2pos) < maxD
        cond2 = abs(c1pos + p) + abs(c2pos) < maxD * NN
        if cond1 and cond2:  # we can short Z19_B, long Z19_D
            c1pos = c1pos + p
            mtm -= p * state.B * txnCost

    bbb.at[i, 'Z19_POS'] = round(c1pos, 1)
    # MTM = prevMTM + prev position x change in spread
    bbb.at[i, "MTM"] = mtm

    # print(round(c1pos, 1))

# plot MTM
print(bbb)
bbb = bbb.set_index('Time')
bbb.MTM.plot()
plt.show()