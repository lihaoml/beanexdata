import pandas as pd
import iso8601

path = "~/.beanex/data/"

def loadData(asof, pair):
    # load txn data for pair and asof
    bntxn = pd.read_csv(path + "/bin_txn_" + pair + "_" + asof + ".csv")
    # fctxn = pd.read_csv(path + "/fco_txn_" + pair + "_" + asof + ".csv")
    hbtxn = pd.read_csv(path + "/huo_txn_" + pair + "_" + asof + ".csv")

    bntxn['Time'] = bntxn['Time'].apply(iso8601.parse_date)
    # fctxn['Time'] = fctxn['Time'].apply(iso8601.parse_date)
    hbtxn['Time'] = hbtxn['Time'].apply(iso8601.parse_date)

    bntxn = bntxn.set_index('Time')
    hbtxn = hbtxn.set_index('Time')
    # fctxn = fctxn.set_index('Time')

    bntxn['Volume'] = bntxn.Price * bntxn.Quantity
    # fctxn['Volume'] = fctxn.Price * fctxn.Quantity
    hbtxn['Volume'] = hbtxn.Price * hbtxn.Quantity

    return bntxn, hbtxn # , fctxn


