import pandas as pd
import numpy as np

def backtest(signals, target):
    res = signals.apply(lambda col: col * target)[:-1]
    ret = res.apply(lambda x: x.sum()).rename("Return")
    # std = res.apply(lambda x: x.std()).rename("StDev")
    dd = res.apply(maxdd).rename("MaxDD")
    accuracy = res.apply(predictionAccuracy).rename("Accuracy")
    sharpe1 = res.apply(sharpe1h).rename("Sharpe1H")
    sharpe5 = res.apply(sharpe5m).rename("Sharpe5m")
    txn = signals.apply(lambda col: col.diff().abs().sum()).rename("TXN")

    return res, pd.DataFrame([ret, dd, accuracy, sharpe1, sharpe5, txn])

def maxdd(pnl):
    cumpnl = pnl.cumsum()
    roll_max = cumpnl.cummax()
    dd = cumpnl - roll_max
    return dd.min()

def predictionAccuracy(pnl):
    win = pnl.gt(0)
    loss = pnl.lt(0)
    return win.sum() / (win.sum() + loss.sum())

def sharpe1h(pnl):
    pnl1h = pnl.resample("1h").sum()
    return pnl1h.mean() / pnl1h.std() * np.sqrt(365*24)

def sharpe5m(pnl):
    pnl1h = pnl.resample("300s").sum()
    return pnl1h.mean() / pnl1h.std() * np.sqrt(365*24*12)

# # res.plot(y=['close_diff'], figsize=(15,4))
# #newdf = [res.close_diff[1:], res.move]
# #res[["close_diff", "move"]].resample("60s").median().plot(figsize=(15,4))
# res = res[:-1]
# print(res.head())
# print(res[['move', 'close_diff']].corr())
