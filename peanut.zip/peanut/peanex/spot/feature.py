import pandas as pd
import numpy as np

# Features ------------------------------------

def txnFeatures(txn, freq):
    # extract features from transaction raw data given a frequency
    bvol = txn.Volume.resample(freq).sum().rename('Volume')
    buyvolRaw = txn.Volume * txn.Maker
    sellvolRaw = txn.Volume - buyvolRaw
    vwap = (bvol / txn.Quantity.resample(freq).sum()).rename('VWAP')
    buyvol = buyvolRaw.resample(freq).sum().rename('BuyVolume')
    sellvol = sellvolRaw.resample(freq).sum().rename('SellVolume')
    bsratio = buyvol / (buyvol + sellvol).rename('BSRatio')
    ohlc = txn.Price.resample(freq).ohlc()
    return pd.concat([bvol, buyvol, sellvol, vwap, bsratio, ohlc], axis=1)

# SIGNALS -----------------------------------------

def signal_BuySellDiff(features):
    return pd.DataFrame({"BuySellDiff" : np.sign(features.BuyVolume - features.SellVolume)})

def signal_BuySellDiff2(features):
    stdev = features.Volume.std()
    def bsr(x):
        if x > 0.8:
            return 1.0
        elif x < 0.2:
            return -1.0
        else:
            return 0.0
    def sma(x):
        if x > 0.001:
            return 1.0
        elif x < -0.001:
            return -1.0
        else:
            return 0.0
    def g(x, y, v):
        if v > 2*stdev:
            return x # (x+y)/2
        else:
            return 0.0
    bsratio = features.BuyVolume / (features.BuyVolume + features.SellVolume)

    quantity = features.Volume / features.VWAP
    longWindow = 3
    shortWindow = 1
    long = features.Volume.rolling(longWindow).sum() / quantity.rolling(longWindow).sum()
    short = features.Volume.rolling(shortWindow).sum() / quantity.rolling(shortWindow).sum()
    smaco = (short - long) / long

    r = map(g, bsratio.apply(bsr), smaco.apply(sma), features.Volume)
    # return pd.DataFrame({"BuySellDiff" : bsratio.apply(f)})
    r = pd.DataFrame({"BuySellDiff": r})
    print(r)
    r = r.set_index(bsratio.index)
    return r

def signal_CloseDiff(ex1Features, ex2Features):
    return pd.DataFrame({"CloseDiff" : np.sign(ex1Features.close - ex2Features.close)})

def signal_SMACO(features, longWindow, shortWindow):
    quantity = features.Volume / features.VWAP
    long = features.Volume.rolling(longWindow).sum() / quantity.rolling(longWindow).sum()
    short = features.Volume.rolling(shortWindow).sum() / quantity.rolling(shortWindow).sum()
    return pd.DataFrame({"SMACO_" + str(longWindow) + "_" + str(shortWindow) : np.sign(short - long)})

# target --------------------------------

def target_NextMove(features):
    move = (features.close - features.open) / features.open
    return move.shift(-1)


# utils -----------------------
def print_full(x):
    pd.set_option('display.max_rows', len(x))
    pd.set_option('display.max_columns', None)
    pd.set_option('display.width', 2000)
    # pd.set_option('display.float_format', '{:20,.2f}'.format)
    pd.set_option('display.max_colwidth', -1)
    print(x)
    pd.reset_option('display.max_rows')
    pd.reset_option('display.max_columns')
    pd.reset_option('display.width')
    pd.reset_option('display.float_format')
    pd.reset_option('display.max_colwidth')