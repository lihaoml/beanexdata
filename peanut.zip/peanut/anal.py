from pandas.plotting import register_matplotlib_converters

register_matplotlib_converters()
from peanex.spot.load import *
from peanex.spot.feature import *
from peanex.spot.eval import *

# bn, hb, fc = loadData('2020-01-30', 'BTCUSDT')
bn, hb = loadData('2020-01-30', 'BTCUSDT')

bnFeatures = txnFeatures(bn, '5s')
hbFeatures = txnFeatures(hb, '5s')
#fcFeatures = txnFeatures(fc, '5s')

#sig1 = signal_CloseDiff(bnFeatures, fcFeatures).add_prefix("BN_FC_")
sig2 = signal_BuySellDiff(bnFeatures).add_prefix("BN_")
#sig3 = signal_CloseDiff(hbFeatures, fcFeatures).add_prefix("HB_FC_")
sig4 = signal_BuySellDiff2(bnFeatures).add_prefix("BN2_")
#sig5 = signal_BuySellDiff(fcFeatures).add_prefix("FC_")
sig6 = signal_SMACO(bnFeatures, 3, 1).add_prefix("BN_")
sig7 = signal_SMACO(hbFeatures, 3, 1).add_prefix("HB_")
#sig8 = signal_SMACO(fcFeatures, 3, 1).add_prefix("FC_")
sig9 = signal_SMACO(bnFeatures, 6, 2).add_prefix("BN_")
sig10 = signal_SMACO(hbFeatures, 6, 2).add_prefix("HB_")
#sig11 = signal_SMACO(fcFeatures, 6, 2).add_prefix("FC_")

sig12 = ((sig6.BN_SMACO_3_1 + sig2.BN_BuySellDiff)/2).rename("COMBO")
print(sig4)
print(abs(sig4).sum())
target = target_NextMove(bnFeatures)

# signals = pd.concat([sig1, sig2, sig3, sig4, sig5, sig6, sig7, sig8, sig9, sig10, sig11, sig12], axis=1) #, sig2, sig3, sig4])
signals = pd.concat([sig2, sig4, sig6, sig7, sig9, sig10, sig12], axis=1) #, sig2, sig3, sig4])

print(signals)
res, resSummary = backtest(signals, target)

print_full(resSummary)


# # now if we use close_diff as signal, the estimated pnl will be sign(close_diff) * move
# signal1 = np.sign(res.close_diff)
# signal2 = np.sign(bbuyvol5s - bsellvol5s)
# #signal2 = ((bbuyvol5s - bsellvol5s) / (bbuyvol5s + bsellvol5s)).apply(lambda x: 1 if x > 0.8 else -1 if x < -0.8 else 0)
# #signal3 = ((fbuyvol5s - fsellvol5s) / (fbuyvol5s + fsellvol5s)).apply(lambda x: 1 if x > 0.8 else -1 if x < -0.8 else 0)
# signal = (signal1 + signal2)/2 # (signal1 + signal2)/2
#
# pnl1h.cumsum().plot()
# pnl.cumsum().plot()
# # pnl300s.cumsum().plot()
# benchmark = res.move
# benchmark.cumsum().plot()
# res.plot.scatter(x='close_diff', y='move')

# #fig, ax = plt.subplots()
# #candlestick_ohlc(ax, bntxn, width=0.6, colorup='g', colordown='r')
